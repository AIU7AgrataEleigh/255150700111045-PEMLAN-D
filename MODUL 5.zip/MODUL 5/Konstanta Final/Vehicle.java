public class Vehicle{

    //Nomor 3
    //private final double load; 

    private double load; 

    //Nomor 4 
    private static final double maxLoad = 10000;

    //Nomor 2
    // public Vehicle (double max){ 
    //     this.maxLoad = max; 
    // } // Diaktifkan maka error

    public double getLoad(){ 
        return this.load; 
    } 

    public double getMaxLoad(){
        return this.maxLoad; 
    } 

    public boolean addBox(double weight){ 
        double temp = 0.0D; 
        temp = this.load + weight; 
        if(temp <= maxLoad){ 
            this.load = this.load + weight; 
            return true; 
        } 
        else{ 
            return false; 
        } 
    } 
}
