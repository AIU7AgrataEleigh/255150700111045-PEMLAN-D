public class Aritmatika {
    public void hitungPenjumlahan(int a,int b){ 
        int nilai = a+b; 
        System.out.println("nilai penjumlahan adalah : "+nilai); 

        //Nomor 4 : Ini tidak menyebabkan eror, karena hitung perkalian
        //adalah tipe static
        // hitungPerkalian(a, b);
    }

    public static void hitungPerkalian(int a, int b){  
        int nilaiPerkalian = a*b; 
        System.out.println("nilai perkalian adalah : "+nilaiPerkalian);
        
        //Nomor 5 : Ini akan error karena hitungPenjumlahan adalah non static
        //hitungPenjumlahan(a,b);
    }

    public static void hitungPengurangan(int a, int b){  
        int nilai = a-b; 
        System.out.println("nilai pengurangan adalah : "+nilai); 
    } 

    //Nomor 6: Method Pembagian
    public void hitungPembagian(String nil1, String nil2){
        double value1 = Double.parseDouble(nil1);
        double value2 = Double.parseDouble(nil2);
        double nilaiPembagian = value1/value2;
        System.out.println("nilai pembagian adalah : " +nilaiPembagian); 
    }
}
