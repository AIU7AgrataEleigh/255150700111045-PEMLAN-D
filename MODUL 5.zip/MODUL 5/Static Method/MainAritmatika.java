import java.util.Scanner; 
public class MainAritmatika { 
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in); 

        //Nomor 3 : Perlu dilakukan instansiasi obyek dari class tersebut
        Aritmatika a = new Aritmatika();

        System.out.print("masukkan nilai 1 : "); 
        int nil1 = in.nextInt(); 
        System.out.print("masukkan nilai 2 : "); 
        int nil2 = in.nextInt(); 
        //memanggil method static 
        Aritmatika.hitungPengurangan(nil1, nil2); 

        System.out.print("masukkan nilai 1 : "); 
        nil1 = in.nextInt(); 
        System.out.print("masukkan nilai 2 : "); 
        nil2 = in.nextInt(); 
        //memanggil method static 
        Aritmatika.hitungPerkalian(nil1, nil2);

        System.out.print("masukkan nilai 1 : "); 
        int value1 = in.nextInt(); 
        System.out.print("masukkan nilai 2 : "); 
        int value2 = in.nextInt(); 
        //memanggil method NONstatic harus melalui objek  Aritmatika a = new Aritmatika(); 
        a.hitungPenjumlahan(value1, value2); 
    
        //Nomor 6
        System.out.print("masukkan nilai 1 : ");
        String nilai1 = in.next();
        System.out.print("masukkan nilai 2 : ");
        String nilai2 = in.next();
        //memanggil method hasilPembagian
        a.hitungPembagian(nilai1, nilai2);

    } 
}
