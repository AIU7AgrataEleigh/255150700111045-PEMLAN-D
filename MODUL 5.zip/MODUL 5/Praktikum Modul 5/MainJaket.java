import java.util.Scanner;
public class MainJaket{
    public static void main(String[] args) {
        Scanner input = new Scanner (System.in);
        Jaket jaket = new Jaket();

        System.out.println("====================================================");
        System.out.println("            SELAMAT DATANG DI CV LABKOMDAS          ");
        System.out.println("====================================================");
        System.out.println("                  RINCIAN HARGA JAKET               ");
        System.out.println();
        System.out.println("""
                Harga Satuan (Normal)
                Jaket A : Rp. 100.000
                Jaket B : Rp. 125.000
                Jaket C : Rp. 175.000

                Harga Satuan (Diskon)
                Jaket A : Rp. 95.000
                Jaket B : Rp. 120.000
                Jaket C : Rp. 160.000

               ====================================================
                """);
        System.out.println("Silahkan Inputkan Jumlah Pembelian Jaket!");
        System.out.print("Masukkan jumlah jaket A : ");
        int jumlahJaketA = input.nextInt();
        System.out.print("Masukkan jumlah jaket B : ");
        int jumlahJaketB = input.nextInt();
        System.out.print("Masukkan jumlah jaket C : ");
        int jumlahJaketC = input.nextInt();
        
        jaket.setDataJaket(jumlahJaketA, jumlahJaketB, jumlahJaketC);

        jaket.display();

        input.close();
    
    }
}