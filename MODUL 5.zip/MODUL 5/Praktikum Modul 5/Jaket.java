public class Jaket{
    private final double JAKET_A = 100000;
    private final double JAKET_B = 125000;
    private final double JAKET_C = 175000;

    private int jumlahA, jumlahB, jumlahC;

    public void setDataJaket(int a, int b, int c){
        this.jumlahA = a;
        this.jumlahB = b;
        this.jumlahC = c;
    }

    public double hargaJaketA (){
        if (jumlahA <= 100){
            return jumlahA*JAKET_A;
        }
        else{
            return jumlahA*95000;
        }
    }

    public double hargaJaketB (){
        if (jumlahB <= 100){
            return jumlahB*JAKET_B;
        }
        else{
            return jumlahB*120000;
        }
    }

    public double hargaJaketC(){
        if (jumlahC <= 100){
            return jumlahC *JAKET_C;
        }
        else{
            return jumlahC*160000;
        }
    }

    public void display(){

        double totalA = hargaJaketA();
        double totalB = hargaJaketB();
        double totalC = hargaJaketC();
        double totalSeluruh = totalA + totalB + totalC;

        System.out.println("====================================================");
        System.out.println("                      PEMBELIAN                     ");
        System.out.println("====================================================");
        System.out.printf("Jaket A (%d pcs)       : Rp %,.2f\n", jumlahA, totalA);
        System.out.printf("Jaket B (%d pcs)       : Rp %,.2f\n", jumlahB, totalB);
        System.out.printf("Jaket C (%d pcs)       : Rp %,.2f\n", jumlahC, totalC);
        System.out.println("----------------------------------------------------");
        System.out.printf("TOTAL KESELURUHAN      : Rp %,.2f\n", totalSeluruh);
        System.out.println("====================================================");
        System.out.println("           TERIMA KASIH SUDAH BERBELANJA            ");
        System.out.println("====================================================");
        
    }

}